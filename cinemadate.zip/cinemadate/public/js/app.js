/* ══════════════════════════════════════════════════════════════
   CinemaDate — Frontend App Logic
   ════════════════════════════════════════════════════════════ */

const socket = io();

/* ─────────────── State ─────────────── */
let myName = "";
let roomCode = "";
let isLocalAction = false;     // prevent feedback loops on sync
let subtitleObjectURL = null;
let subtitlesEnabled = true;
let isReady = false;
let isMuted = false;
let volumeLevel = 1;

/* ─────────────── DOM Refs ─────────────── */
const $ = id => document.getElementById(id);

const lobbyEl      = $("lobby");
const roomEl       = $("room");
const usernameEl   = $("username");
const roomCodeInEl = $("room-code-input");
const lobbyErr     = $("lobby-error");
const btnCreate    = $("btn-create");
const btnJoin      = $("btn-join");
const tabBtns      = document.querySelectorAll(".tab-btn");
const tabPanels    = document.querySelectorAll(".tab-panel");

const roomCodeDisplay = $("room-code-display");
const btnCopyCode     = $("btn-copy-code");
const roomUsersEl     = $("room-users");
const btnReady        = $("btn-ready");
const partnerStatus   = $("partner-status");

const sourceLoaderEl  = $("source-loader");
const videoWrapperEl  = $("video-wrapper");
const fileInput       = $("file-input");
const urlInput        = $("url-input");
const btnLoadUrl      = $("btn-load-url");
const videoEl         = $("main-video");
const progressBar     = $("progress-bar");
const progressFill    = $("progress-fill");
const progressThumb   = $("progress-thumb");
const btnPlayPause    = $("btn-play-pause");
const iconPlay        = $("icon-play");
const iconPause       = $("icon-pause");
const btnMute         = $("btn-mute");
const volumeSlider    = $("volume-slider");
const timeDisplay     = $("time-display");
const btnSubToggle    = $("btn-subtitle-toggle");
const subInput        = $("sub-input");
const subLabel        = $("sub-label");
const subNameEl       = $("sub-name");
const btnFullscreen   = $("btn-fullscreen");
const syncToast       = $("sync-toast");
const emojiBurst      = $("emoji-burst");

const chatMessages = $("chat-messages");
const chatInput    = $("chat-input");
const btnSend      = $("btn-send");
const toastEl      = $("toast");

/* ═══════════════════════════════════════════
   LOBBY
═══════════════════════════════════════════ */

// Tab switching
tabBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    tabBtns.forEach(b => b.classList.remove("active"));
    tabPanels.forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    $(`tab-${btn.dataset.tab}`).classList.add("active");
    lobbyErr.textContent = "";
  });
});

btnCreate.addEventListener("click", () => {
  const name = usernameEl.value.trim();
  if (!name) return showLobbyError("Please enter your name.");
  socket.emit("create-room", { name }, (res) => {
    if (!res.success) return showLobbyError(res.error);
    enterRoom(res.code, name, res.roomData);
  });
});

btnJoin.addEventListener("click", () => {
  const name = usernameEl.value.trim();
  const code = roomCodeInEl.value.trim().toUpperCase();
  if (!name) return showLobbyError("Please enter your name.");
  if (code.length < 4) return showLobbyError("Enter the room code.");
  socket.emit("join-room", { name, code }, (res) => {
    if (!res.success) return showLobbyError(res.error);
    enterRoom(res.code, name, res.roomData);
  });
});

// Allow Enter to submit
usernameEl.addEventListener("keydown", e => { if (e.key === "Enter") btnCreate.click(); });
roomCodeInEl.addEventListener("keydown", e => { if (e.key === "Enter") btnJoin.click(); });
roomCodeInEl.addEventListener("input", e => {
  e.target.value = e.target.value.toUpperCase();
});

function showLobbyError(msg) {
  lobbyErr.textContent = msg;
  setTimeout(() => { lobbyErr.textContent = ""; }, 3500);
}

/* ═══════════════════════════════════════════
   ENTER ROOM
═══════════════════════════════════════════ */

function enterRoom(code, name, roomData) {
  myName = name;
  roomCode = code;

  lobbyEl.classList.remove("active");
  roomEl.classList.add("active");

  roomCodeDisplay.textContent = code;
  document.title = `CinemaDate · Room ${code}`;

  renderUsers(roomData.users);

  // Request sync if the other person already has a source loaded
  socket.emit("request-sync");
}

/* ─── Users Pills ─── */
function renderUsers(users) {
  roomUsersEl.innerHTML = "";
  users.forEach(u => {
    const pill = document.createElement("div");
    pill.className = `user-pill${u.id === socket.id ? " me" : ""}${u.ready ? " ready" : ""}`;
    pill.dataset.userId = u.id;
    pill.innerHTML = `
      <div class="user-avatar">${u.name.substring(0,2)}</div>
      <span>${u.name}${u.id === socket.id ? " (you)" : ""}</span>
    `;
    roomUsersEl.appendChild(pill);
  });
}

/* ─── Copy code ─── */
btnCopyCode.addEventListener("click", () => {
  const link = `${window.location.origin}?room=${roomCode}`;
  navigator.clipboard.writeText(link).then(() => showToast("Link copied! Send it to your partner 💌", "success"));
});

// Auto-fill room code from URL param
window.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const r = params.get("room");
  if (r) {
    roomCodeInEl.value = r.toUpperCase();
    tabBtns.forEach(b => b.classList.remove("active"));
    tabPanels.forEach(p => p.classList.remove("active"));
    document.querySelector('[data-tab="join"]').classList.add("active");
    $("tab-join").classList.add("active");
  }
});

/* ═══════════════════════════════════════════
   READY SYSTEM
═══════════════════════════════════════════ */

btnReady.addEventListener("click", () => {
  isReady = !isReady;
  btnReady.classList.toggle("active", isReady);
  socket.emit("ready-toggle", { ready: isReady });
});

socket.on("ready-update", ({ users, allReady }) => {
  renderUsers(users);
  if (allReady) {
    showToast("Both ready! Starting in 1 second… 🎬", "success");
  }
});

/* ═══════════════════════════════════════════
   VIDEO SOURCE
═══════════════════════════════════════════ */

fileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const url = URL.createObjectURL(file);
  loadVideoSource(url, "file");
  socket.emit("video-action", { type: "source", src: null, srcType: "file" });
  showToast(`Loaded: ${file.name}`, "success");
  addSystemMessage(`${myName} loaded a video file.`);
});

btnLoadUrl.addEventListener("click", () => {
  const src = urlInput.value.trim();
  if (!src) return;
  loadVideoSource(src, "url");
  socket.emit("video-action", { type: "source", src, srcType: "url" });
  addSystemMessage(`${myName} loaded a video URL.`);
});

urlInput.addEventListener("keydown", e => { if (e.key === "Enter") btnLoadUrl.click(); });

function loadVideoSource(src, type) {
  sourceLoaderEl.classList.add("hidden");
  videoWrapperEl.classList.remove("hidden");
  videoEl.src = src;
  videoEl.load();
  videoEl.currentTime = 0;
}

/* ═══════════════════════════════════════════
   VIDEO PLAYER CONTROLS
═══════════════════════════════════════════ */

// Play / Pause
btnPlayPause.addEventListener("click", togglePlayPause);
videoEl.addEventListener("click", togglePlayPause);

function togglePlayPause() {
  if (videoEl.paused) {
    videoEl.play();
  } else {
    videoEl.pause();
  }
}

videoEl.addEventListener("play", () => {
  iconPlay.classList.add("hidden");
  iconPause.classList.remove("hidden");
  if (!isLocalAction) {
    socket.emit("video-action", { type: "play", currentTime: videoEl.currentTime });
  }
});

videoEl.addEventListener("pause", () => {
  iconPlay.classList.remove("hidden");
  iconPause.classList.add("hidden");
  if (!isLocalAction) {
    socket.emit("video-action", { type: "pause", currentTime: videoEl.currentTime });
  }
});

// Seeking via progress bar
let isDragging = false;

progressBar.addEventListener("mousedown", startSeek);
progressBar.addEventListener("touchstart", startSeek, { passive: true });

function startSeek(e) {
  isDragging = true;
  handleSeek(e);
}

document.addEventListener("mousemove", (e) => { if (isDragging) handleSeek(e); });
document.addEventListener("touchmove", (e) => { if (isDragging) handleSeek(e.touches[0]); }, { passive: true });
document.addEventListener("mouseup", endSeek);
document.addEventListener("touchend", endSeek);

function handleSeek(e) {
  const rect = progressBar.getBoundingClientRect();
  const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  const time = ratio * videoEl.duration;
  if (!isNaN(time)) videoEl.currentTime = time;
}

function endSeek() {
  if (!isDragging) return;
  isDragging = false;
  if (!isLocalAction) {
    socket.emit("video-action", { type: "seek", currentTime: videoEl.currentTime });
  }
}

// Time update → progress bar
videoEl.addEventListener("timeupdate", () => {
  if (!videoEl.duration) return;
  const pct = (videoEl.currentTime / videoEl.duration) * 100;
  progressFill.style.width = `${pct}%`;
  progressThumb.style.left = `${pct}%`;
  timeDisplay.textContent = `${formatTime(videoEl.currentTime)} / ${formatTime(videoEl.duration)}`;
});

// Volume
volumeSlider.addEventListener("input", () => {
  videoEl.volume = volumeSlider.value;
  volumeLevel = volumeSlider.value;
  isMuted = volumeLevel == 0;
  btnMute.textContent = isMuted ? "🔇" : "🔊";
});
btnMute.addEventListener("click", () => {
  isMuted = !isMuted;
  videoEl.muted = isMuted;
  btnMute.textContent = isMuted ? "🔇" : "🔊";
});

// Fullscreen
btnFullscreen.addEventListener("click", () => {
  if (!document.fullscreenElement) {
    videoWrapperEl.requestFullscreen?.();
  } else {
    document.exitFullscreen?.();
  }
});

// Keyboard shortcuts
document.addEventListener("keydown", (e) => {
  if (e.target.tagName === "INPUT") return;
  if (e.code === "Space") { e.preventDefault(); togglePlayPause(); }
  if (e.code === "ArrowRight") { videoEl.currentTime = Math.min(videoEl.duration || 0, videoEl.currentTime + 10); }
  if (e.code === "ArrowLeft")  { videoEl.currentTime = Math.max(0, videoEl.currentTime - 10); }
  if (e.code === "KeyM") { btnMute.click(); }
  if (e.code === "KeyF") { btnFullscreen.click(); }
});

function formatTime(sec) {
  if (!sec || isNaN(sec)) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`
    : `${m}:${String(s).padStart(2,"0")}`;
}

/* ═══════════════════════════════════════════
   SUBTITLE SUPPORT
═══════════════════════════════════════════ */

subInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (ev) => {
    const content = ev.target.result;
    const ext = file.name.split(".").pop().toLowerCase();
    applySubtitle(content, ext, file.name);

    // Relay subtitle to partner (base64 encode)
    const b64 = btoa(unescape(encodeURIComponent(content)));
    socket.emit("subtitle-upload", { content: b64, ext, name: file.name });
    showToast(`Subtitle loaded: ${file.name}`, "success");
  };
  reader.readAsText(file, "UTF-8");
});

function applySubtitle(content, ext, name) {
  if (subtitleObjectURL) URL.revokeObjectURL(subtitleObjectURL);

  let vttContent = content;
  if (ext === "srt") vttContent = srtToVtt(content);

  const blob = new Blob([vttContent], { type: "text/vtt" });
  subtitleObjectURL = URL.createObjectURL(blob);

  // Remove old tracks
  while (videoEl.textTracks.length > 0) {
    const t = videoEl.textTracks[0];
    t.mode = "disabled";
  }
  const oldTrack = videoEl.querySelector("track");
  if (oldTrack) videoEl.removeChild(oldTrack);

  const track = document.createElement("track");
  track.kind = "subtitles";
  track.label = name;
  track.src = subtitleObjectURL;
  track.default = true;
  videoEl.appendChild(track);
  videoEl.textTracks[0].mode = subtitlesEnabled ? "showing" : "hidden";

  subLabel.classList.remove("hidden");
  subNameEl.textContent = name;
}

// SRT → VTT converter
function srtToVtt(srt) {
  let vtt = "WEBVTT\n\n";
  const blocks = srt.trim().split(/\n\s*\n/);
  for (const block of blocks) {
    const lines = block.trim().split("\n");
    if (lines.length < 2) continue;
    let i = 0;
    if (/^\d+$/.test(lines[i].trim())) i++;  // skip sequence number
    const timeLine = lines[i]?.replace(/,/g, ".");
    if (!timeLine?.includes("-->")) continue;
    const textLines = lines.slice(i + 1).join("\n");
    vtt += timeLine + "\n" + textLines + "\n\n";
  }
  return vtt;
}

btnSubToggle.addEventListener("click", () => {
  subtitlesEnabled = !subtitlesEnabled;
  btnSubToggle.classList.toggle("active", subtitlesEnabled);
  if (videoEl.textTracks[0]) {
    videoEl.textTracks[0].mode = subtitlesEnabled ? "showing" : "hidden";
  }
  socket.emit("subtitle-toggle", { enabled: subtitlesEnabled });
});

/* ═══════════════════════════════════════════
   SOCKET EVENTS — VIDEO SYNC
═══════════════════════════════════════════ */

socket.on("video-action", (data) => {
  const { type, currentTime, src, srcType } = data;
  isLocalAction = true;

  if (type === "source" && srcType === "url" && src) {
    loadVideoSource(src, "url");
    addSystemMessage(`${data.from} loaded a video.`);
  } else if (type === "source" && srcType === "file") {
    addSystemMessage(`${data.from} loaded a video file. Please load the same file on your end.`);
    showToast("Partner loaded a file — load the same file to sync!", "");
  } else if (type === "play") {
    videoEl.currentTime = currentTime;
    videoEl.play().catch(() => {});
    showSyncToast();
  } else if (type === "pause") {
    videoEl.currentTime = currentTime;
    videoEl.pause();
    showSyncToast();
  } else if (type === "seek") {
    videoEl.currentTime = currentTime;
    showSyncToast();
  }

  setTimeout(() => { isLocalAction = false; }, 300);
});

socket.on("sync-state", (state) => {
  if (state.src && state.srcType === "url") {
    loadVideoSource(state.src, "url");
    videoEl.currentTime = state.currentTime;
    if (state.playing) videoEl.play().catch(() => {});
  }
});

socket.on("subtitle-upload", ({ content, ext, name }) => {
  const decoded = decodeURIComponent(escape(atob(content)));
  applySubtitle(decoded, ext, name);
  showToast(`Partner shared subtitles: ${name}`, "success");
});

socket.on("subtitle-toggle", ({ enabled }) => {
  subtitlesEnabled = enabled;
  btnSubToggle.classList.toggle("active", enabled);
  if (videoEl.textTracks[0]) {
    videoEl.textTracks[0].mode = enabled ? "showing" : "hidden";
  }
});

/* ═══════════════════════════════════════════
   PARTNER EVENTS
═══════════════════════════════════════════ */

socket.on("partner-joined", ({ name }) => {
  partnerStatus.textContent = `${name} is here ♥`;
  partnerStatus.classList.remove("offline");
  partnerStatus.classList.add("online");
  addSystemMessage(`${name} joined the room.`);
  showToast(`${name} joined! 💕`, "success");
  // Refresh users list
  socket.emit("request-sync");
});

socket.on("partner-left", ({ name }) => {
  partnerStatus.textContent = "Partner left the room";
  partnerStatus.classList.remove("online");
  partnerStatus.classList.add("offline");
  addSystemMessage(`${name} left the room.`);
  showToast(`${name} disconnected.`, "error");
});

/* ═══════════════════════════════════════════
   CHAT
═══════════════════════════════════════════ */

function sendMessage() {
  const text = chatInput.value.trim();
  if (!text) return;
  socket.emit("chat-message", { text });
  chatInput.value = "";
}

btnSend.addEventListener("click", sendMessage);
chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});

socket.on("chat-message", (msg) => {
  appendMessage(msg);
});

function appendMessage(msg) {
  const isMe = msg.fromId === socket.id;
  const div = document.createElement("div");
  div.className = `chat-msg ${isMe ? "mine" : "theirs"}`;
  div.innerHTML = `
    ${!isMe ? `<span class="msg-sender">${escapeHtml(msg.from)}</span>` : ""}
    <div class="msg-bubble">${escapeHtml(msg.text)}</div>
    <span class="msg-time">${new Date(msg.timestamp).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}</span>
  `;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addSystemMessage(text) {
  const div = document.createElement("div");
  div.className = "chat-msg system";
  div.innerHTML = `<div class="msg-bubble">${escapeHtml(text)}</div>`;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

/* ═══════════════════════════════════════════
   EMOJI REACTIONS
═══════════════════════════════════════════ */

document.querySelectorAll(".emoji-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const emoji = btn.dataset.emoji;
    socket.emit("emoji-reaction", { emoji });
    spawnEmoji(emoji);
  });
});

socket.on("emoji-reaction", ({ emoji, from }) => {
  spawnEmoji(emoji);
  addSystemMessage(`${from} reacted ${emoji}`);
});

function spawnEmoji(emoji) {
  const el = document.createElement("span");
  el.className = "burst-emoji";
  el.textContent = emoji;
  el.style.left = `${20 + Math.random() * 60}%`;
  el.style.bottom = "80px";
  emojiBurst.appendChild(el);
  setTimeout(() => el.remove(), 2600);
}

/* ═══════════════════════════════════════════
   UTILS
═══════════════════════════════════════════ */

function showSyncToast() {
  syncToast.classList.remove("hidden");
  setTimeout(() => syncToast.classList.add("hidden"), 1600);
}

let toastTimer;
function showToast(msg, type = "") {
  clearTimeout(toastTimer);
  toastEl.textContent = msg;
  toastEl.className = `toast ${type}`;
  toastTimer = setTimeout(() => {
    toastEl.classList.add("hidden");
  }, 3500);
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str;
  return d.innerHTML;
}
